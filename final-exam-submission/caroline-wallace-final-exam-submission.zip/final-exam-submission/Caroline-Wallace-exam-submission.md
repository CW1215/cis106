# Final Submission

## Questions 1
![q1](q1.1.png)

## Questions 2
![q2](q2.1.png)

## Questions 3
![q3](q3.1.png)