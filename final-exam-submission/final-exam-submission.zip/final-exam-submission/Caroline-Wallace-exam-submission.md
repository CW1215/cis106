# Final Submission

## Questions 1
![q1](q1.1.png)
![q1](q1.2.png)
![q1](q1.3.png)
![q2](q2.1.png)
![q3](q3.1.png)

## Question 2
![q2](q22.1.png)

## Question 3
![q3](q33.1.png)