![profile](profile.png){width=50% style="display: block; margin: 0 auto"} 

# Caroline Wallace
----------------------------
## Education
* **Marist High School** - *September 2017 - June 2020*
  * Bayonne, NJ
* **Hudson County Community College** - *June 2020 - September 2023*
  * Jersey City, NJ
* **Passaic County Community College** - *September 2023 - current*
  * Paterson, NJ
----------------------------------
## Course Work

| Computer Concepts/Applications | Java Programming |
|----------|----------|
|**Linux Fundamentals**| **Programming Fundamentals**|

-------------------------------------
## Volunteer
* **[Girl Scouts](https://www.girlscouts.org/)** - * September 2005 - December 2020*
  * Field trips, skill building, sport clinics, community service, and cultural exchanges.
------------------------------

### My GitHub
[cis106 Work](https://github.com/CW1215/cis106)